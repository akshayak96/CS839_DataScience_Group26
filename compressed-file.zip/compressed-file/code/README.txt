STEP 1: run.ipynb --- extracts candidates and creates training and testing features
STEP 2: cross_valid.ipynb --- cross validation, finds classifier M 
STEP 3: debugM.ipynb --- debug classifier M from step 2, applies rules and creates final classifier X