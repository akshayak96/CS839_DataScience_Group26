Entity type: Person Name (ex: full names, surnames, names without surnames)
Tag: <person>....</>